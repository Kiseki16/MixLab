// @ts-ignore
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
// @ts-ignore
import { isAdmin, isAuthenticated, decodeToken } from './lib/jwtUtils'

// --- Public Pages ---
// @ts-ignore
import Landing from './pages/Landing'
// @ts-ignore
import Booking from './pages/Bookings' // This is the User-side booking page
// @ts-ignore
import BookingDetails from './pages/BookingDetails'
// @ts-ignore
import UserProfile from './pages/Profile'
// @ts-ignore
import Reservations from './pages/Reservations'
// @ts-ignore
import About from './pages/About'
// @ts-ignore
import Services from './pages/Services'
// @ts-ignore
import Gallery from './pages/Gallery'
// @ts-ignore
import Contact from './pages/Contact'
// @ts-ignore
import MusicLessons from './pages/MusicLessons'
// @ts-ignore
import BandRehearsal from './pages/BandRehearsal'
// @ts-ignore
import Recording from './pages/Recording'
// @ts-ignore
import LiveRoom from './pages/LiveRoom'
// @ts-ignore
import ControlRoom from './pages/ControlRoom'
// @ts-ignore
import MainHall from './pages/MainHall'

// --- Auth Pages ---
// @ts-ignore
import Login from './pages/auth/Login'
// @ts-ignore
import Register from './pages/auth/Register'
// @ts-ignore
import AccountCreated from './pages/auth/Account-created'
// @ts-ignore
import ForgotPassword from './pages/auth/Forgot-password'
// @ts-ignore
import VerifyOTP from './pages/auth/Verify-OTP'
// @ts-ignore
import VerifyResetOTP from './pages/auth/Verify-reset-otp'
// @ts-ignore
import ResetPassword from './pages/auth/Reset-password'

// --- Admin Pages ---
// @ts-ignore
import AdminDashboard from './pages/admin/AdminDashboard'
// @ts-ignore
import AdminBookings from './pages/admin/AdminBookings'
// @ts-ignore
import AdminProfile from './pages/admin/AdminProfile'
// @ts-ignore
import AdminReports from './pages/admin/AdminReports'
// @ts-ignore
import AdminUsers from './pages/admin/AdminUsers'
// @ts-ignore
import AdminModules from './pages/admin/AdminModules'
// @ts-ignore
import AdminInstructors from './pages/admin/AdminInstructors'
// @ts-ignore
import AdminPayments from './pages/admin/AdminPayments'
// @ts-ignore
import AdminNotifications from './pages/admin/AdminNotifications'
// @ts-ignore
import AdminActivityLogs from './pages/admin/AdminActivityLogs'

// --- Reusable Admin Protected Route ---
// This allows any child component to be protected by the token check
// @ts-ignore
const ProtectedAdminRoute = ({ children }) => {
  const authenticated = isAuthenticated();
  const admin = isAdmin();

  // Debug logging
  const userStr = localStorage.getItem('user');
  const userRole = userStr ? JSON.parse(userStr).role : 'none';
  const token = localStorage.getItem('token');
  const decodedToken = token ? decodeToken(token) : null;

  console.log('🔐 ProtectedAdminRoute check:', {
    authenticated,
    admin,
    role: userRole,
    tokenExists: !!token,
    tokenRole: decodedToken?.role,
    userFromStorage: userStr,
    pathname: window.location.pathname
  });

  // Development bypass: allow access if token exists (assume admin for testing)
  const isDevelopment = import.meta.env.DEV;
  if (isDevelopment && token && !admin) {
    console.log('🔧 DEV: Token exists but role check failed, allowing access for development');
    return children;
  }

  if (!authenticated) {
    console.warn('❌ Not authenticated, redirecting to login');
    return <Navigate to="/auth/login" replace />;
  }

  if (!admin) {
    console.warn('❌ Not admin, redirecting to landing page. Current role:', userRole);
    return <Navigate to="/" replace />;
  }

  console.log('✅ Admin access granted');
  return children;
};

function App() {
  return (
    <BrowserRouter>
      <Routes>
        {/* Public Landing */}
        <Route path="/" element={<Landing />} />

        {/* Auth Routes */}
        <Route path="/auth/login" element={<Login />} />
        <Route path="/auth/register" element={<Register />} />
        <Route path="/auth/Account-created" element={<AccountCreated />} />
        <Route path="/auth/Forgot-password" element={<ForgotPassword />} />
        <Route path="/auth/Verify-otp" element={<VerifyOTP />} />
        <Route path="/auth/verify-reset-otp" element={<VerifyResetOTP />} />
        <Route path="/auth/Reset-password" element={<ResetPassword />} />
        
        {/* User Routes */}
        <Route path="/Bookings" element={<Booking />} />
        <Route path="/booking/:id" element={<BookingDetails />} />
        <Route path="/Reservations" element={<Reservations />} />
        <Route path="/Profile" element={<UserProfile />} />
        
        {/* Landing Page Sub-Routes */}
        <Route path="/about" element={<About />} />
        <Route path="/services" element={<Services />} />
        <Route path="/gallery" element={<Gallery />} />
        <Route path="/contact" element={<Contact />} />

        {/* Service Detail Pages */}
        <Route path="/music-lessons" element={<MusicLessons />} />
        <Route path="/band-rehearsal" element={<BandRehearsal />} />
        <Route path="/recording" element={<Recording />} />
        <Route path="/live-room" element={<LiveRoom />} />
        <Route path="/control-room" element={<ControlRoom />} />
        <Route path="/main-hall" element={<MainHall />} />

        {/* --- ADMIN ROUTES --- */}
        
        {/* Admin Dashboard */}
        <Route 
          path="/admin/dashboard" 
          element={
            <ProtectedAdminRoute>
              <AdminDashboard />
            </ProtectedAdminRoute>
          } 
        />

        {/* Admin Users */}
        <Route 
          path="/admin/users" 
          element={
            <ProtectedAdminRoute>
              <AdminUsers />
            </ProtectedAdminRoute>
          } 
        />

        {/* Admin Bookings */}
        <Route 
          path="/admin/bookings" 
          element={
            <ProtectedAdminRoute>
              <AdminBookings />
            </ProtectedAdminRoute>
          } 
        />

        {/* Admin Modules & Lessons */}
        <Route 
          path="/admin/modules" 
          element={
            <ProtectedAdminRoute>
              <AdminModules />
            </ProtectedAdminRoute>
          } 
        />

        {/* Admin Instructors */}
        <Route 
          path="/admin/instructors" 
          element={
            <ProtectedAdminRoute>
              <AdminInstructors />
            </ProtectedAdminRoute>
          } 
        />

        {/* Admin Payments */}
        <Route 
          path="/admin/payments" 
          element={
            <ProtectedAdminRoute>
              <AdminPayments />
            </ProtectedAdminRoute>
          } 
        />

        {/* Admin Notifications */}
        <Route 
          path="/admin/notifications" 
          element={
            <ProtectedAdminRoute>
              <AdminNotifications />
            </ProtectedAdminRoute>
          } 
        />

        {/* Admin Activity Logs */}
        <Route 
          path="/admin/activity" 
          element={
            <ProtectedAdminRoute>
              <AdminActivityLogs />
            </ProtectedAdminRoute>
          } 
        />

        {/* Admin Reports */}
        <Route 
          path="/admin/reports" 
          element={
            <ProtectedAdminRoute>
              <AdminReports />
            </ProtectedAdminRoute>
          } 
        />

        {/* Admin Profile */}
        <Route 
          path="/admin/profile" 
          element={
            <ProtectedAdminRoute>
              <AdminProfile />
            </ProtectedAdminRoute>
          } 
        />

        {/* Fallback/404 Route */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  )
}

export default App